# Bantrab UI

Bantrab UI is a reusable React and TypeScript component library for the Bantrab UI Kit / Design System.

## Requirements

- Node.js 22
- npm

## Installation

```bash
npm install
```

## Scripts

- `npm run dev`: starts Storybook on port 6006.
- `npm run storybook`: starts Storybook on port 6006.
- `npm run build`: builds the library.
- `npm run build:storybook`: builds Storybook.
- `npm run typecheck`: runs TypeScript checks.
- `npm run test`: runs Jest tests.
- `npm run lint`: runs ESLint.
- `npm run format`: formats files with Prettier.
- `npm run changeset`: creates a changeset.
- `npm run release`: publishes with Changesets.

## Basic Usage

```tsx
import { Button, ThemeProvider } from '@bantrab/ui';
import '@bantrab/ui/styles.css';

export function App() {
  return (
    <ThemeProvider theme="light">
      <Button variant="primary">Continuar</Button>
    </ThemeProvider>
  );
}
```

## Storybook

```bash
npm run storybook
```

## Tests

```bash
npm run test
```

## Build

```bash
npm run build
```

The build outputs ESM, CommonJS, TypeScript declarations, and global CSS in `dist`.

## Project Structure

- `src/foundations`: design tokens in TypeScript and CSS.
- `src/themes`: semantic theme variables and `ThemeProvider`.
- `src/components`: public React components.
- `src/primitives`: low-level reusable primitives.
- `src/hooks`: shared React hooks.
- `src/styles`: global CSS entrypoint.
- `docs`: design system notes.

## Conventions

Components use `bt-` prefixed classes and consume semantic CSS variables. Foundation tokens are exported from `@bantrab/ui/tokens` and represented as CSS variables in `@bantrab/ui/styles.css`.

React and React DOM are peer dependencies, so consuming applications provide their own React runtime. This library is prepared for future publication to a private registry for use by other Bantrab React projects, including projects that do not use Vite.
